CREATE FUNCTION sec_to_gc(double precision)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT CASE WHEN $1 < 0 THEN 0::float8 WHEN $1/(2*earth()) > 1 THEN pi()*earth() ELSE 2*earth()*asin($1/(2*earth())) END
$$;

