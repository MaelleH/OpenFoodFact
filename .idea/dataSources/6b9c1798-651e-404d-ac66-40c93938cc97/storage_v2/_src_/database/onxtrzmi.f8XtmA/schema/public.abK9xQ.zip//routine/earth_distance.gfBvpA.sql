CREATE FUNCTION earth_distance(earth, earth)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT sec_to_gc(cube_distance($1, $2))
$$;

